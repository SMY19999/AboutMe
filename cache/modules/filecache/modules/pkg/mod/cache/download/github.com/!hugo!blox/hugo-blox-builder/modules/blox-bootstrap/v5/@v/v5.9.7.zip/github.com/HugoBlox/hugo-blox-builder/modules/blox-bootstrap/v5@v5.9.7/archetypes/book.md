---
# Documentation: https://docs.hugoblox.com/managing-content/

title: "{{ replace .Name "-" " " | title }}"
linktitle: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
type: book
summary: ""
---
